<div class="container">

    <footer>
        <div class="row">
            <div class="col-lg-12" style="margin-left: 25%">
                <p>INSTITUTO FEDERAL CATARINENSE - CAMPUS ARAQUARI - Alunos: Hugo Gutzmann Puga, Tainá C. Vollmann e Cecilia de Borba</p>
            </div>

        </div>
    </footer>
</div>