<footer class="ui inverted vertical footer segment" style="position absolute; bottom: 0;">
    <div class="ui center aligned container" style="padding: 2em;">
        <p>INSTITUTO FEDERAL CATARINENSE - CAMPUS ARAQUARI - Alunos: Hugo Gutzmann Puga, Tainá C. Vollmann e Cecilia de Borba</p>
    </div>
</footer>
