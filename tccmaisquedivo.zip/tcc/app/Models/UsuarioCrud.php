<?php
require_once 'DBConnection.php';
require_once 'Usuario.php';
require_once 'Fator.php';
require_once 'FatorUsuario.php';
require_once 'LivrosFatorUsuario.php';
require_once '../Controlers/ControlerFormulario.php';
class UsuarioCrud
{
    //SEMPRE QUE A CLASSE FOR INSTANCIADA, JA FAZ A CONEXÃO E GUARDA
    private $conexao;

    public function __construct()
    {
        $this->conexao = DBConnection::getConexao();
    }

    //RETORNA VERDADEIRO OU FALSA

    public function LoginUsuario(Usuario $user)
    {
        $sql = $this->conexao->prepare("SELECT * FROM Usuario WHERE us_email = '{$user->getUsEmail()}' AND us_senha = '{$user->getUsSenha()}'");
        $sql->execute();
        $resultado = $sql->rowCount();
        return $resultado;
    }

    public function verificaAdmin($tip_usuario)
    {

        if ($tip_usuario == '2') {
            return true;
        } else {
            return false;
        }
    }


    public function getUsuario($email)
    {
        //RETORNA UMA CATEGORIA, DADO UM ID
        //FAZER A CONSULTA
        $sql = "select * from Usuario where us_email='{$email}'";
        $resultado = $this->conexao->query($sql);
        //FETCH - TRANSFORMA O RESULTADO EM UM ARRAY ASSOCIATIVO
        $usuario = $resultado->fetch(PDO::FETCH_ASSOC);
        //CRIAR OBJETO DO TIPO CATEGORIA - USANDO OS VALORES DA CONSULTA
        $objetoUsuario = new Usuario(
            $usuario['us_nome'],
            $usuario['us_email'],
            $usuario['us_senha'],
            $usuario['us_datanascimento'],
            $usuario['us_sexo'],
            $usuario['us_id'],
            $usuario['tip_usuario']
        );
        //RETORNAR UM OBJETO CATEGORIA COM OS VALORES
        return $objetoUsuario;
    }

    public function getUsuarioId($us_id)
    {
        //RETORNA UMA CATEGORIA, DADO UM ID
        //FAZER A CONSULTA
        $sql = "select * from Usuario where us_id='{$us_id}'";
        $resultado = $this->conexao->query($sql);
        //FETCH - TRANSFORMA O RESULTADO EM UM ARRAY ASSOCIATIVO
        $usuario = $resultado->fetch(PDO::FETCH_ASSOC);
        //CRIAR OBJETO DO TIPO CATEGORIA - USANDO OS VALORES DA CONSULTA
        $objetoUsuario = new Usuario(
            $usuario['us_nome'],
            $usuario['us_email'],
            $usuario['us_senha'],
            $usuario['us_datanascimento'],
            $usuario['us_sexo'],
            $usuario['us_id'],
            $usuario['tip_usuario']

        );
        //RETORNAR UM OBJETO CATEGORIA COM OS VALORES
        return $objetoUsuario;
    }


    public function getUsuarios()
    {
        $sql = "SELECT * FROM Usuario";

        $resultado = $this->conexao->query($sql);

        $usuarios = $resultado->fetchAll(PDO::FETCH_ASSOC);

        foreach ($usuarios as $usuario) {
            $nome = $usuario['us_nome'];
            $senha = $usuario['us_senha'];
            $email = $usuario['us_email'];
            $datanascimento = $usuario['us_datanascimento'];
            $sexo = $usuario['us_sexo'];
            $iduser = $usuario['us_id'];
            $tipuser = $usuario['tip_usuario'];

            $obj = new Usuario($nome, $senha, $email, $datanascimento, $sexo, $iduser, $tipuser);
            $listaUsuario[] = $obj;
        }
        return $listaUsuario;
    }

    public function updateUsuario(Usuario $user)
    {

        $this->conexao = DBConnection::getConexao();

        $sql = "UPDATE Usuario SET us_nome = '{$user->us_nome}', us_senha ='{$user->us_senha}', us_email = '{$user->us_email}'
        WHERE us_id = '{$user->us_id}'";

        try {//TENTA EXECUTAR A INSTRUCAO

            $this->conexao->exec($sql);
        } catch (PDOException $e) {//EM CASO DE ERRO, CAPTURA A MENSAGEM
            return $e->getMessage();
        }
    }

    public function insertUsuario(Usuario $user)
    {

        //EFETUA A CONEXAO
        $this->conexao = DBConnection::getConexao();
        //MONTA O TEXTO DA INSTRUÇÂO SQL
        $sql = "insert into Usuario (us_nome, us_email,us_senha,us_datanascimento, us_sexo, tip_usuario) 
        values ('{$user->getUsNome()}','{$user->getUsEmail()}','{$user->getUsSenha()}','{$user->getUsDatanascimento()}','{$user->getUsSexo()}',1)";

        try {//TENTA EXECUTAR A INSTRUCAO

            $this->conexao->exec($sql);
            $this->conexao->exec($sql);
        } catch (PDOException $e) {//EM CASO DE ERRO, CAPTURA A MENSAGEM
            return $e->getMessage();
        }
    }

    public function deleteUsuario($id)
    {

        //EFETUA A CONEXAO
        $this->conexao = DBConnection::getConexao();
        //MONTA O TEXTO DA INSTRUÇÂO SQL
        $sql = "DELETE FROM Usuario WHERE us_id = '{$id}'";
        try {//TENTA EXECUTAR A INSTRUCAO

            $this->conexao->exec($sql);
        } catch (PDOException $e) {//EM CASO DE ERRO, CAPTURA A MENSAGEM
            return $e->getMessage();
        }
    }

    public function getResultadoFormulario(FatorUsuario $resultadoFormularioTL,$resultadoFormularioGL,$resultadoFormularioAU,$resultadoFormularioAP,$resultadoFormularioCL,$resultadoFormularioLA)
    {
        $excluir = "delete from fatorusuario where fu_idusuario = '{$resultadoFormularioTL->getFuIdusuario()}'";

        $sql1 = "INSERT INTO fatorusuario (fu_id,fu_idfator,fu_idusuario,fu_nota) 
  VALUES (null,'{$resultadoFormularioTL->getFuIdfator()}',
    '{$resultadoFormularioTL->getFuIdusuario()}',
  '{$resultadoFormularioTL->getFuNota()}')";

        $sql2 = "INSERT INTO fatorusuario (fu_id,fu_idfator,fu_idusuario,fu_nota) 
  VALUES (null,'{$resultadoFormularioGL->getFuIdfator()}',
    '{$resultadoFormularioGL->getFuIdusuario()}',
  '{$resultadoFormularioGL->getFuNota()}')";

        $sql3 = "INSERT INTO fatorusuario (fu_id,fu_idfator,fu_idusuario,fu_nota) 
  VALUES (null,'{$resultadoFormularioAU->getFuIdfator()}',
    '{$resultadoFormularioAU->getFuIdusuario()}',
  '{$resultadoFormularioAU->getFuNota()}')";

        $sql4 = "INSERT INTO fatorusuario (fu_id,fu_idfator,fu_idusuario,fu_nota) 
  VALUES (null,'{$resultadoFormularioAP->getFuIdfator()}',
    '{$resultadoFormularioAP->getFuIdusuario()}',
  '{$resultadoFormularioAP->getFuNota()}')";

        $sql5 = "INSERT INTO fatorusuario (fu_id,fu_idfator,fu_idusuario,fu_nota) 
  VALUES (null,'{$resultadoFormularioCL->getFuIdfator()}',
    '{$resultadoFormularioCL->getFuIdusuario()}',
  '{$resultadoFormularioCL->getFuNota()}')";

        $sql6 = "INSERT INTO fatorusuario (fu_id,fu_idfator,fu_idusuario,fu_nota) 
  VALUES (null,'{$resultadoFormularioLA->getFuIdfator()}',
    '{$resultadoFormularioLA->getFuIdusuario()}',
  '{$resultadoFormularioLA->getFuNota()}')";


        //PRIMEIRO EXCLUI TUDO ANTES DE ADICIONAR UM NOVO

        $this->conexao->exec($excluir);
        $this->conexao->exec($sql1);
        $this->conexao->exec($sql2);
        $this->conexao->exec($sql3);
        $this->conexao->exec($sql4);
        $this->conexao->exec($sql5);
        $this->conexao->exec($sql6);
    }

    public function setFatores($usuario){
//FALTA ADICIONAR A AVALIAÇÃO DOS USUARIOS E "EM ALTA" À CONSULTA

        /*Aqui devemos fazer a consulta que vai alimentar os parâmetros do usuário, pra depois ir complementando
        a sintaxe com todas as preferências dele*/
        //O primeiro parâmetro é o fator livro
        $sqlfator1 ="select * from fatorusuario where fu_idusuario = {$usuario->us_id} and fu_idfator = 1;";
        $resultadofator1 = $this->conexao->query($sqlfator1);

        $fator1 = $resultadofator1->fetchall(PDO::FETCH_ASSOC);
        foreach ($fator1 as $fatortamanho) {
            $tamanholivro = $fatortamanho['fu_nota'];
        }

//O segundo parâmetro é o fator gênero livro
        $sqlfator2 = "select * from fatorusuario where fu_idusuario = {$usuario->us_id} and fu_idfator = 2;";
        $resultadofator2 = $this->conexao->query($sqlfator2);

        $fator2 = $resultadofator2->fetchall(PDO::FETCH_ASSOC);
        foreach ($fator2 as $fatorgenero) {
            $generolivro = $fatorgenero['fu_nota'];
        }
//Acho que esse parâmetro aqui não vai precisar, poistodo o usuario  terá gêneros preferenciais cadastrados

//O terceiro parâmetro é a avaliação dos usuários
        $sqlfator3 = "select * from fatorusuario where fu_idusuario = {$usuario->us_id} and fu_idfator = 3;";
        $resultadofator3 = $this->conexao->query($sqlfator3);

        $fator3 = $resultadofator3->fetchall(PDO::FETCH_ASSOC);
        foreach ($fator3 as $fatoravaliacao) {
            $avaliacao = $fatoravaliacao['fu_nota'];
        }
//Acho que não vai precisar também, pois você falou que pra segunda não será necessário

//O quarto parâmetro é o ano de publicação/
        $sqlfator4 = "select * from fatorusuario where fu_idusuario = {$usuario->us_id} and fu_idfator = 4;";
        $resultadofator4 = $this->conexao->query($sqlfator4);

        $fator4 = $resultadofator4->fetchall(PDO::FETCH_ASSOC);
        foreach ($fator4 as $fatorano) {
            $anopublicacao = $fatorano['fu_nota'];
        }

//O quinto parâmetro é a censura do livro
        $sqlfator5 = "select * from fatorusuario where fu_idusuario = {$usuario->us_id} and fu_idfator = 5;";
        $resultadofator5 = $this->conexao->query($sqlfator5);

        $fator5 = $resultadofator5->fetchall(PDO::FETCH_ASSOC);
        foreach ($fator5 as $fatorcensura) {
            $censura = $fatorcensura['fu_nota'];
        }

//O sexto parâmetro é livros em alta
        $sqlfator6 = "select * from fatorusuario where fu_idusuario = {$usuario->us_id} and fu_idfator = 6;";
        $resultadofator6 = $this->conexao->query($sqlfator6);

//Acho que também não vai precisar pra segunda
//        $fator6 = $resultadofator6->fetchall(PDO::FETCH_ASSOC);
//        foreach ($fator6 as $fatorlivrosemalta) {
//            $livrosemalta = $fatorlivrosemalta['fu_nota'];
//        }

        /*Abaixo você tem a sintaxe que vai executar em toda consulta, mas que será complementada
        de acordo com as preferências do usuário, que constam na tabela fatoresusuario
        O exemplo do código abaixo é na linguagem php*/
        $sintaxesql = "select livro.li_titulo, genero.ge_descricao from livro, generolivro, genero where livro.li_idlivro = generolivro.gl_idlivro and generolivro.gl_idgenero = genero.ge_id";
//aqui vamos colocar o primeiro parâmetro na consulta, que é a quantidade de páginas do livro
        $sintaxesql = $sintaxesql . "  and livro.li_paginas < ".$tamanholivro;

//aqui vamos colocar o segundo parâmetro na consulta, que é uma subconsulta na tabela de gêneros do usuário/
        $sintaxesql = $sintaxesql . "  and genero.ge_id in (select ug_idgenero form usuariogenero
													where ug_idusuario = {usuario->us_id})";

//aqui vamos colocar o quarto parâmetro na consulta, que é o ano de publicação do livro
        $sintaxesql = $sintaxesql . "  and livro.li_ano > ".$anopublicacao;

//aqui vamos colocar o quinto parâmetro na consulta, que é a censura do livro
        $sintaxesql = $sintaxesql . "  and livro.li_censura > ".$censura;

//daí é só executar o código, e se precisar é só incluir mais campos no teu select/


        print_r($sintaxesql);die;
    }
    public function getFatorUsuario($idusuario)
    {
        //RETORNA UMA CATEGORIA, DADO UM ID
        //FAZER A CONSULTA
        $sql = "select * from fatorusuario where fu_idusuario='{$idusuario}'";
        $resultado = $this->conexao->query($sql);
        //FETCH - TRANSFORMA O RESULTADO EM UM ARRAY ASSOCIATIVO
        $fatorusuario = $resultado->fetch(PDO::FETCH_ASSOC);
        //CRIAR OBJETO DO TIPO CATEGORIA - USANDO OS VALORES DA CONSULTA
        $objetoUsuario = new FatorUsuario(
            $fatorusuario['fu_id'],
            $fatorusuario['fu_idfator'],
            $fatorusuario['fu_idusuario'],
            $fatorusuario['fu_nota']
        );
        //RETORNAR UM OBJETO CATEGORIA COM OS VALORES
        return $objetoUsuario;
    }
}

