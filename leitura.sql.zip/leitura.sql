-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 10-Ago-2018 às 19:56
-- Versão do servidor: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `leitura`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `avaliacaolivro`
--

CREATE TABLE `avaliacaolivro` (
  `al_idavaliacaolivro` int(11) NOT NULL,
  `al_idlivro` int(11) DEFAULT NULL,
  `al_idusuario` int(11) DEFAULT NULL,
  `al_datahora` datetime DEFAULT NULL,
  `al_nota` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `biblioteca`
--

CREATE TABLE `biblioteca` (
  `bi_id` int(11) NOT NULL,
  `bi_idlivro` int(11) DEFAULT NULL,
  `bi_idprateleira` int(11) DEFAULT NULL,
  `bi_datainclusao` datetime DEFAULT NULL,
  `bi_observacao` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `fatores`
--

CREATE TABLE `fatores` (
  `fa_id` int(11) NOT NULL,
  `fa_descricao` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='	';

-- --------------------------------------------------------

--
-- Estrutura da tabela `fatorlivro`
--

CREATE TABLE `fatorlivro` (
  `fl_id` int(11) NOT NULL,
  `fl_idfator` int(11) DEFAULT NULL,
  `fl_idlivro` int(11) DEFAULT NULL,
  `fl_idusuario` int(11) DEFAULT NULL,
  `fl_valor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `fatorusuario`
--

CREATE TABLE `fatorusuario` (
  `fu_id` int(11) NOT NULL,
  `fu_idfator` int(11) DEFAULT NULL,
  `fu_idusuario` int(11) DEFAULT NULL,
  `fu_nota` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `genero`
--

CREATE TABLE `genero` (
  `ge_id` int(11) NOT NULL,
  `ge_descricao` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `genero`
--

INSERT INTO `genero` (`ge_id`, `ge_descricao`) VALUES
(1, 'Ambito Religioso'),
(2, 'Ação'),
(3, 'Autobiografia'),
(5, 'Biografia'),
(6, 'Comédia'),
(7, 'Conto'),
(8, 'Crônica'),
(9, 'Drama'),
(10, 'Épico'),
(11, 'Fábula'),
(12, 'Fantasia'),
(13, 'Farsa'),
(14, 'Ficção'),
(15, 'Haicai'),
(16, 'Melodrama'),
(17, 'Novela'),
(18, 'Paródia'),
(19, 'Poesia'),
(20, 'Romance'),
(21, 'Sátira'),
(22, 'Soneto'),
(23, 'Suspense'),
(24, 'Terror'),
(25, 'Tragédia'),
(26, 'Tragicomédia');

-- --------------------------------------------------------

--
-- Estrutura da tabela `generolivro`
--

CREATE TABLE `generolivro` (
  `gl_id` int(11) NOT NULL,
  `gl_idlivro` int(11) DEFAULT NULL,
  `gl_idgenero` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `imagem`
--

CREATE TABLE `imagem` (
  `img_id` int(11) NOT NULL,
  `arquivo` int(40) NOT NULL,
  `data` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `livro`
--

CREATE TABLE `livro` (
  `li_idlivro` int(11) NOT NULL,
  `li_titulo` varchar(200) DEFAULT NULL,
  `li_ano` int(11) DEFAULT NULL,
  `li_autor` varchar(100) DEFAULT NULL,
  `li_paginas` int(11) DEFAULT NULL,
  `li_editora` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `li_censura` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `livro`
--

INSERT INTO `livro` (`li_idlivro`, `li_titulo`, `li_ano`, `li_autor`, `li_paginas`, `li_editora`, `li_censura`) VALUES
(4, 'Outro livro', 2012, 'Outro cara', 1235, 'Outra editora', 21),
(5, 'As CrÃ´nicas de Narnia', 2000, 'C.S. Lewis', 400, 'Harpercollins USA', 12),
(6, 'Quem Ã© vocÃª Alasca?', 2014, 'John Green', 230, 'NÃ£o informado', 13),
(7, 'Pequeno Principe', 1943, 'Antoine De Saint-Exuper', 96, 'Reynal & Hitchcock, Gallimard', 12),
(8, 'As vantagens de ser invisÃ­vel', 1999, 'Stephen Chbosky', 223, ' Pocket Books e Gallery Publishing Group', 16),
(9, 'Eyu nÃ£o sei', 0, 'um cara', 200, 'Outra editora', 14),
(10, '', 0, '', 0, '', 0),
(11, 'Novo Livro', 0, 'Um autor ai', 150, 'Uma editora ai', 14);

-- --------------------------------------------------------

--
-- Estrutura da tabela `prateleira`
--

CREATE TABLE `prateleira` (
  `pr_id` int(11) NOT NULL,
  `pr_descricao` varchar(150) DEFAULT NULL,
  `pr_idusuario` int(11) DEFAULT NULL,
  `pr_datacriacao` datetime DEFAULT NULL,
  `pr_status` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `resenha`
--

CREATE TABLE `resenha` (
  `re_id` int(11) NOT NULL,
  `re_idlivro` int(11) DEFAULT NULL,
  `re_idusuario` int(11) DEFAULT NULL,
  `re_data` datetime DEFAULT NULL,
  `re_textoresenha` varchar(4000) DEFAULT NULL,
  `re_status` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `us_id` int(11) NOT NULL,
  `us_nome` varchar(100) DEFAULT NULL,
  `us_email` varchar(200) DEFAULT NULL,
  `us_senha` varchar(200) DEFAULT NULL,
  `us_datanascimento` date DEFAULT NULL,
  `us_sexo` char(1) DEFAULT NULL,
  `tip_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`us_id`, `us_nome`, `us_email`, `us_senha`, `us_datanascimento`, `us_sexo`, `tip_usuario`) VALUES
(1, 'hugo', 'hugo@hugo.com', '123', '2018-07-04', 'm', 2),
(17, 'taina2', 'taina@taina.com', '123', '2000-11-04', 'F', 1),
(18, 'Novo Usuario', 'novo@novo.com', '123', '2000-01-01', 'M', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuariogenero`
--

CREATE TABLE `usuariogenero` (
  `ug_id` int(11) NOT NULL,
  `ug_idgenero` int(11) DEFAULT NULL,
  `ug_idusuario` int(11) DEFAULT NULL,
  `ug_nota` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `avaliacaolivro`
--
ALTER TABLE `avaliacaolivro`
  ADD PRIMARY KEY (`al_idavaliacaolivro`),
  ADD KEY `al_livro_idx` (`al_idlivro`),
  ADD KEY `al_usuario_idx` (`al_idusuario`);

--
-- Indexes for table `biblioteca`
--
ALTER TABLE `biblioteca`
  ADD PRIMARY KEY (`bi_id`),
  ADD KEY `bi_livro_idx` (`bi_idlivro`),
  ADD KEY `bi_prateleira_idx` (`bi_idprateleira`);

--
-- Indexes for table `fatores`
--
ALTER TABLE `fatores`
  ADD PRIMARY KEY (`fa_id`);

--
-- Indexes for table `fatorlivro`
--
ALTER TABLE `fatorlivro`
  ADD PRIMARY KEY (`fl_id`),
  ADD KEY `fl_fator_idx` (`fl_idfator`),
  ADD KEY `fl_livro_idx` (`fl_idlivro`),
  ADD KEY `fl_usuario_idx` (`fl_idusuario`);

--
-- Indexes for table `fatorusuario`
--
ALTER TABLE `fatorusuario`
  ADD PRIMARY KEY (`fu_id`),
  ADD KEY `fu_fator_idx` (`fu_idfator`),
  ADD KEY `fu_usuario_idx` (`fu_idusuario`);

--
-- Indexes for table `genero`
--
ALTER TABLE `genero`
  ADD PRIMARY KEY (`ge_id`);

--
-- Indexes for table `generolivro`
--
ALTER TABLE `generolivro`
  ADD PRIMARY KEY (`gl_id`),
  ADD KEY `gl_livro_idx` (`gl_idlivro`),
  ADD KEY `gl_genero_idx` (`gl_idgenero`);

--
-- Indexes for table `imagem`
--
ALTER TABLE `imagem`
  ADD PRIMARY KEY (`img_id`);

--
-- Indexes for table `livro`
--
ALTER TABLE `livro`
  ADD PRIMARY KEY (`li_idlivro`);

--
-- Indexes for table `prateleira`
--
ALTER TABLE `prateleira`
  ADD PRIMARY KEY (`pr_id`),
  ADD KEY `pr_usuario_idx` (`pr_idusuario`);

--
-- Indexes for table `resenha`
--
ALTER TABLE `resenha`
  ADD PRIMARY KEY (`re_id`),
  ADD KEY `re_livro_idx` (`re_idlivro`),
  ADD KEY `re_usuario_idx` (`re_idusuario`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`us_id`);

--
-- Indexes for table `usuariogenero`
--
ALTER TABLE `usuariogenero`
  ADD PRIMARY KEY (`ug_id`),
  ADD KEY `ug_genero_idx` (`ug_idgenero`),
  ADD KEY `ug_usuario_idx` (`ug_idusuario`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `avaliacaolivro`
--
ALTER TABLE `avaliacaolivro`
  MODIFY `al_idavaliacaolivro` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `biblioteca`
--
ALTER TABLE `biblioteca`
  MODIFY `bi_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fatores`
--
ALTER TABLE `fatores`
  MODIFY `fa_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fatorlivro`
--
ALTER TABLE `fatorlivro`
  MODIFY `fl_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fatorusuario`
--
ALTER TABLE `fatorusuario`
  MODIFY `fu_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `genero`
--
ALTER TABLE `genero`
  MODIFY `ge_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `generolivro`
--
ALTER TABLE `generolivro`
  MODIFY `gl_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `imagem`
--
ALTER TABLE `imagem`
  MODIFY `img_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `livro`
--
ALTER TABLE `livro`
  MODIFY `li_idlivro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `prateleira`
--
ALTER TABLE `prateleira`
  MODIFY `pr_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `resenha`
--
ALTER TABLE `resenha`
  MODIFY `re_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `us_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `usuariogenero`
--
ALTER TABLE `usuariogenero`
  MODIFY `ug_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `avaliacaolivro`
--
ALTER TABLE `avaliacaolivro`
  ADD CONSTRAINT `al_livro` FOREIGN KEY (`al_idlivro`) REFERENCES `livro` (`li_idlivro`),
  ADD CONSTRAINT `al_usuario` FOREIGN KEY (`al_idusuario`) REFERENCES `usuario` (`us_id`);

--
-- Limitadores para a tabela `biblioteca`
--
ALTER TABLE `biblioteca`
  ADD CONSTRAINT `bi_livro` FOREIGN KEY (`bi_idlivro`) REFERENCES `livro` (`li_idlivro`),
  ADD CONSTRAINT `bi_prateleira` FOREIGN KEY (`bi_idprateleira`) REFERENCES `prateleira` (`pr_id`);

--
-- Limitadores para a tabela `fatorlivro`
--
ALTER TABLE `fatorlivro`
  ADD CONSTRAINT `fl_fator` FOREIGN KEY (`fl_idfator`) REFERENCES `fatores` (`fa_id`),
  ADD CONSTRAINT `fl_livro` FOREIGN KEY (`fl_idlivro`) REFERENCES `livro` (`li_idlivro`),
  ADD CONSTRAINT `fl_usuario` FOREIGN KEY (`fl_idusuario`) REFERENCES `usuario` (`us_id`);

--
-- Limitadores para a tabela `fatorusuario`
--
ALTER TABLE `fatorusuario`
  ADD CONSTRAINT `fu_fator` FOREIGN KEY (`fu_idfator`) REFERENCES `fatores` (`fa_id`),
  ADD CONSTRAINT `fu_usuario` FOREIGN KEY (`fu_idusuario`) REFERENCES `usuario` (`us_id`);

--
-- Limitadores para a tabela `generolivro`
--
ALTER TABLE `generolivro`
  ADD CONSTRAINT `gl_genero` FOREIGN KEY (`gl_idgenero`) REFERENCES `genero` (`ge_id`),
  ADD CONSTRAINT `gl_livro` FOREIGN KEY (`gl_idlivro`) REFERENCES `livro` (`li_idlivro`);

--
-- Limitadores para a tabela `prateleira`
--
ALTER TABLE `prateleira`
  ADD CONSTRAINT `pr_usuario` FOREIGN KEY (`pr_idusuario`) REFERENCES `usuario` (`us_id`);

--
-- Limitadores para a tabela `resenha`
--
ALTER TABLE `resenha`
  ADD CONSTRAINT `re_livro` FOREIGN KEY (`re_idlivro`) REFERENCES `livro` (`li_idlivro`),
  ADD CONSTRAINT `re_usuario` FOREIGN KEY (`re_idusuario`) REFERENCES `usuario` (`us_id`);

--
-- Limitadores para a tabela `usuariogenero`
--
ALTER TABLE `usuariogenero`
  ADD CONSTRAINT `ug_genero` FOREIGN KEY (`ug_idgenero`) REFERENCES `genero` (`ge_id`),
  ADD CONSTRAINT `ug_usuario` FOREIGN KEY (`ug_idusuario`) REFERENCES `usuario` (`us_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
