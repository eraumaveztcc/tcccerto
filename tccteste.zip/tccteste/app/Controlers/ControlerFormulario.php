<?php
require_once "../Models/UsuarioCrud.php";
require_once "../Models/FatorLivro.php";
require_once "../Models/CrudGenero.php";

if (isset($_GET['acao'])){
    $action = $_GET['acao'];
}else{
    $action = 'index';
}
switch ($action){
    case 'formulario':
        if (!isset($_POST['gravar'])) {
            $id = $_GET['idusuario'];
            @session_start();
            $_SESSION['us_id'] = $id;
            $crud = new UsuarioCrud();
            $usuario = $crud->getUsuarioId($id);
            $tipuser = $usuario->getTipUsuario();

            $crudGenero = new CrudGenero();
            $generos = $crudGenero->getGeneros();
        }else{
            $id = $_POST['getidusuario'];
            @session_start();
            $_SESSION['us_id'] = $id;
            $crud = new UsuarioCrud();
            $usuario = $crud->getUsuarioId($id);
            $tipuser = $usuario->getTipUsuario();

//            $crudFator = new

//            $resultadoFormulario = new FatorFormulario(null,$_POST[]);
//            $crudFormulario = new UsuarioCrud();
//            $formulario = $crudFormulario->getResultadoFormulario();
        }
        include "../View/Template/cabecalho.php";
        include "../View/telas/formulario.php";
        include "../View/Template/rodape.php";



        break;
}