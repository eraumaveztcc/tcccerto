<?php

require '../Models/UsuarioCrud.php';


if (isset($_GET['acao'])){
    $action = $_GET['acao'];
}else{
    $action = 'index';
}

switch ($action){
    case 'index':


        $crudUser = new UsuarioCrud();
        $usuarios = $crudUser->getUsuarios();
        @session_start();
        $_SESSION['id'] = $_GET['iduser'];
        $id = $_SESSION['id'];
        $usuario = $crudUser->getUsuarioId($id);
        $tipuser = $usuario->getTipUsuario();

        include "../View/Template/cabecalho.php";
        include "../View/admin/adminindex.php";

        break;

    case 'editar':

        if (!isset($_POST['gravar'])) {
            $id = $_GET['iduser'];
            $crud= new UsuarioCrud();
            $usuario = $crud->getUsuarioId($id);
            include "../View/telas/editar.php";
        } else {
            $id = $_GET['iduser'];
            $crud = new UsuarioCrud();
            $usuario = $crud->getUsuarioId($id);
            $user = new Usuario($_POST['nome'], $_POST['email'], $_POST['senha'], $usuario->us_datanascimento, $usuario->us_sexo, $usuario->us_id, $usuario->tip_usuario);
            $crud->updateUsuario($user);
            header("Location: ControlerAdmin.php");
        }

        break;

    case 'excluir':

        $iduser = $_GET['iduser'];
        //EXCLUI USUARIO
        $cruduser = new UsuarioCrud();
        $resultado = $cruduser->deleteUsuario($iduser);
        header("Location: ControlerAdmin.php");

        break;

}