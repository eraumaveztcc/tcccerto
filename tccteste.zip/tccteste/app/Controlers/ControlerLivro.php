<?php

require_once "../Models/CrudLivros.php";
require_once "../Models/UsuarioCrud.php";
require_once "../Models/CrudGenero.php";
require_once "../Models/GeneroLivro.php";
require_once "../Models/Resenha.php";
require_once "../Models/Prateleira.php";


if (isset($_GET['acao'])){
    $action = $_GET['acao'];
}else{
    $action = 'index';
}


switch ($action){
    case 'add_livro':


        if (!isset($_POST['gravar'])) {
            $id = $_GET['idusuario'];
            @session_start();
            $_SESSION['us_id'] = $id;
            $crud = new UsuarioCrud();
            $usuario = $crud->getUsuarioId($id);
            $tipuser = $usuario->getTipUsuario();
            $crudGenero = new CrudGenero();
            $generos = $crudGenero->getGeneros();
            include "../View/Template/cabecalho.php";
            include "../View/telas/addlivro.php";
            include "../View/Template/rodape.php";
        } else {
            $idusuario = $_GET['us_id'];
            $livro = new Livros($_POST['li_ano'],
                $_POST['li_autor'],
                $_POST['li_censura'],
                $_POST['li_editora'],
                $_POST['li_paginas'],
                $_POST['li_titulo'],
                null,
                $_POST['getidusuario']);

            $crud = new CrudLivros();
            $id = $crud->addLivro($livro);

            $crud2 = new CrudGenero();
            foreach ($_POST['li_genero'] as $genero) {
                $generoLivro = new GeneroLivro (null,$id, $genero);
                $crud2->addLivroGenero($generoLivro);
            }

            echo "<script>alert('O livro foi cadastrado')</script>";

            header("Location: ControlerUsuario.php?acao=index&idusuario=$idusuario");

        }

        break;

    case 'add_imagem_teste':

        $msg = false;
    if(!isset($_POST['gravarteste'])){
        include "../View/telas/addImagemTeste.php";
    }
        if(isset($_FILES['imagem'])){
            $extensao = strtolower (substr($_FILES['imagem']['name'], -4)); //pega a extensao do arquivo, transforma tudo em minusculo
            $novo_nome = md5(time()) . $extensao; //define novo nome do arquivo criptografado para não ter dois arquivos de mesmo nome
            $diretorio = "../../assets/img/livros/"; //define o diretorio pra onde vai o arquivo

            move_uploaded_file($_FILES['imagem']['tpm_name'], $diretorio.$novo_nome); //coisa o upload

            $sql = "INSERT INTO imagem (img_id, arquivo, data) VALUES (null, '$novo_nome', NOW())";

            if ($mysqlli->query($sql)){
                $msg = "Arquivo enviado com sucesso";

            }else{
                $msg = "falha ao enviar o arquivo";
            }

        }
        break;

    case 'show':
        if (isset($_GET['idusuario'])){
        $id = $_GET['idusuario'];
        @session_start();
        $_SESSION['us_id'] = $id;
        $crud = new UsuarioCrud();
        $usuario = $crud->getUsuarioId($id);
        $tipuser = $usuario->getTipUsuario();
        }else {
            $tipuser = 0;
        }
        $idlivro = $_GET['idlivro'];
        $crudLivro = new CrudLivros();
        $livro = $crudLivro->getLivro($idlivro);

        include "../View/Template/cabecalho.php";
        include "../View/telas/livro.php";
        include "../View/Template/rodape.php";

        break;

    case 'buscar':
        $listaLivros = $crud->buscarLivros($_POST['busca']);

        break;

    case 'add_sinopse':


        if (!isset($_POST['gravar'])) {
            if (isset($_GET['idusuario'])){
            $id = $_GET['idusuario'];
            @session_start();
            $_SESSION['us_id'] = $id;
            $crud = new UsuarioCrud();
            $usuario = $crud->getUsuarioId($id);
            $tipuser = $usuario->getTipUsuario();
            }else{
                $tipuser = 0;
            }

            include "../View/Template/cabecalho.php";
            include "../View/telas/addsinopse.php";
            include "../View/Template/rodape.php";
        }else{

//    require_once "../View/telas/addsinopse.php";
            $idlivro = $_POST['getidlivro'];
            $crudLivro = new CrudLivros();
            $livro = $crudLivro->getLivro($idlivro);
            $idusuario = $_POST['getidusuario'];

            $data1 = new DateTime();
            $data  = $data1->format('Y-m-d H:i:s');
            $sinopseLivro = new Resenha(null, $livro->li_idlivro, $idusuario, $data, $_POST['re_textoresenha'], 1);


            $crud = new CrudLivros();
            $crud->addResenha($sinopseLivro);
            echo "<script>alert('A sinopse foi cadastrada')</script>";
            header("Location: ControlerUsuario.php?acao=index&idusuario=".$idusuario);

        }

        break;
    case 'add_biblioteca':
        $idlivro = $_GET['idlivro'];
        $crudLivro = new CrudLivros();
        $livro = $crudLivro->getLivro($idlivro);
        $idusuario = $_GET['idusuario'];
        $data1 = new DateTime();
        $data  = $data1->format('d-m-Y H:i:s');

        $adiciona = new Prateleira(null, null, $idusuario,$data,null);
        print_r($adiciona);die;
        $crud = new CrudLivros();
        $crud->addPrateleira($adiciona);
print_r($adiciona);
//        header("Location: ControlerUsuario.php:acao=index&idusuario=".$idusuario);
        break;
}


