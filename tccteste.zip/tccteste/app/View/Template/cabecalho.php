<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
<!--  CSS's  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.9/semantic.min.css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.9/semantic.min.js"></script>
</head>
<style>

    .body{
        background-color: #2F3238;
    }
    .ui.secondary.menu{
        background: #26292E;
        position: relative;
        width: 100%;
        height: 60px;
        z-index: 1001;
        -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.25);
        -moz-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.25);
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.25);
    }


    .ui.menu .item>.input input{
        border-radius: 30px;
        font-size: 1em;
        padding-top: .57142857em;
        padding-bottom: .57142857em;

    }

    .ui.menu .item{
        color: white;
    }

</style>
<body class="body">
<div class="ui secondary  menu hum">

    <?php

    if (isset($_GET['idusuario'])){
        $_SESSION['us_id'] = $_GET['idusuario'];
//    }else{
//        echo die;
    }

    ?>
    <a class="header item" href="ControlerUsuario.php?acao=index<?php if (isset($_SESSION['us_id'])) {
//        $idusuario = $_SESSION['us_id'];
        echo "&idusuario=" . $_SESSION['us_id'];
    }
    ?>">Página Inicial</a>
    <?php
    if (isset($_SESSION['us_id'])) {
        $id = $_SESSION['us_id'];

    }else{
        $id = '';
    }
    ?>

    <?php

    if(isset($_SESSION['us_id'])){
        $crud = new UsuarioCrud();

        $usuario = $crud->getUsuarioId($id);
        $tipuser = $usuario->getTipUsuario();

        echo "<a class=\"item\" href=\"?acao=biblioteca&idusuario=<?=$id?>\">Biblioteca</a><a class=\"item\" href=\"ControlerFormulario.php?acao=formulario&idusuario=$id\">Formulário</a>";
    }else{
        echo "";
    }
    ?>

    <?php

      if (isset($_SESSION)){
          $id = $_SESSION['us_id'];
//        echo "<div class=\"ui dropdown item\">Adicionar
//    <i class=\"angle down icon\"></i>
//            <div class=\"menu\">
                   echo "<a class=\"item\" href=\"ControlerLivro.php?acao=add_livro&idusuario=$id\">Adicionar Livro</a>";
//                    "<a class=\"item\" href=\"ControlerLivro.php?acao=add_sinopse&idusuario=$id\">Adicionar Sinopse</a>";
//            </div>

//    </div>";
     }else{
          echo "";
      }
      ?>

    <div class="right menu">
        <div class="item twelve wide">
            <form class="ui icon input" action="ControlerLivro.php?acao=buscar">
                <i class="search icon" href="../../Controlers/ControlerLivro.php?acao=buscar" ></i>
                <input name="busca" type="text" placeholder="Buscar...">
            </form>
        </div>
<!--    Começo do dropdown-->
        <div class="ui dropdown item">
            <i class="user circle icon"></i><?php
            if (!isset($_SESSION['us_id'])){
            echo "Visitante";
            }else{
            $id = $_SESSION['us_id'];
            $crud = new UsuarioCrud();
            $user = $crud->getUsuarioId($id);
            $nome = $user->getUsNome();
            echo $nome;            }
            ?>
            <i class="angle down icon"></i>
            <div class="menu">
                <?php
                if (isset($_SESSION)){

                    $tipuser = $user->getTipUsuario();
                if ($tipuser == 2){
                    $id = $_SESSION['us_id'];
                    echo "<a class=\"item\" href=\"ControlerAdmin.php?iduser=$id\">Área do Admin</a>";
                }else{
                    echo "";
                }
                }else{
                    echo "";
                }
                ?>
                <!--ARRUMAR ISSO AQUI-->
<!--                --><?php
//                $paw = $_SESSION['us_id'];
                if (isset($_SESSION['us_id'])){

                    $idusuario = $_SESSION['us_id'];

                    echo "<a class=\"item\" href=\"?acao=editar&iduser=$idusuario\">Editar</a><a class=\"item\" href=\"?acao=excluir&iduser=$idusuario\">Excluir</a><a class=\"item\" href=\"?acao=logout\">Sair</a>";
                }else{
                    echo "<a class=\"item\" href=\"?acao=login\">Entrar</a>    <a class=\"item\" href=\"?acao=cadastrar\">Cadastrar</a>   ";
                }
//                ?>
<!--                <a class="item" href="?acao=login">Entrar</a>-->
<!--                <a class="item" href="?acao=cadastrar">Cadastrar</a>-->
<!--                <a class="item" href="?acao=editar&iduser=--><?//=$_SESSION['us_id']?><!--">Editar</a>-->
<!--                <a class="item" href="?acao=excluir&iduser=--><?//=$_SESSION['us_id']?><!--">Excluir</a>-->
<!--                <a class="item" href="?acao=logout">Sair</a>-->
            </div>
        </div>
    </div>
<!--       final do dropdown -->
    </div>
</div>
</body>

<script>
    $('.ui.dropdown').dropdown();
</script>

