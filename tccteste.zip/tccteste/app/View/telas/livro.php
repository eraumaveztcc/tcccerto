<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body><br><br><br><br><br><br>
<div class="main ui container center align page">
<div class="ui segment">
<div class="inline field">
        <img href="ControlerLivro.php?acao=show" src="../../assets/img/livros/livro1.jpg" style="height:500px; width:300px">
</div>
    <div class="content">
        <div class="header"><?= $livro->li_titulo ?></div>
        <div class="meta">
            <div class="header"><?= $livro->li_autor ?></div>
        </div>
        <div class="header">
            Classificação:
            <div class="ui star rating" data-rating="0" data-max-rating="5"></div>
        </div>
    </div>
    <br>
<!--    COMEÇA O TESTE-->
    <p>Primeira sinópse</p>
    <?php
    $idlivro=$_GET['idlivro'];
    $crudLivros = new CrudLivros();
    $resenhas = $crudLivros->getResenhas($idlivro);
//    foreach ($resenhas as $resenha): ?>
        <p><?=$resenhas->re_textoresenha?></p>

<!--    --><?php //endforeach ?>

<!-- ACABA O TESTE-->
    <?php
    $idlivro = $livro->li_idlivro;
    $crudGenero = new CrudGenero();
    $generos = $crudGenero->getGeneroLivro($idlivro);
    $iddogenero = $generos->getGlId();

    $generodoLivro =$crudGenero->getGenero($iddogenero);
    ?>
    <a class="ui red label" style="margin-top: 6px"><?= $generodoLivro->ge_descricao ?></a>
    <br>

<!--   Se o usuario for o mesmo que adicionou a sinopse, ele pode editá-la ou excluila, o mesmo vale para o livro-->
    <?php
    $idusuario1 = $resenhas->re_idusuario;
    if (isset($livro->li_idusuario)) {
        $idusuario2 = $livro->li_idusuario;
    }

    if ($idusuario1 == $idusuario){
   echo "<a class=\"item\">Editar sinopse</a><br><a class=\"item\">Excluir sinopse</a>";
    }
    if (isset($idusuario2)){
    if ($idusuario == $idusuario2){
        echo "<a class=\"item\">Editar livro</a><br><a class=\"item\">Excluir livro</a>";
    }
    }
    ?>
    <br>
<!--    se o usuario estiver logado, ele podera adicionar o livro a biblioteca e/ou adicionar uma nova sinopse ao mesmo-->
    <?php if (isset($_SESSION)){ $idusuario=$_SESSION['us_id']; echo "<a>Adicionar livro à biblioteca</a><br><a href='ControlerLivro.php?acao=add_sinopse&idusuario=$idusuario&idlivro=$livro->li_idlivro'>Adicionar Sinópse</a>";} ?>
    <br><br>
    <p>Comentarios:</p>

</div>
</div>
</body>
</html>
<script>
    $('.ui.rating')
        .rating()
    ;
</script>