<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.9/semantic.min.css"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.9/semantic.min.js"></script>

<style>

    body{
        background-color: #2F3238;
    }
    .ui.secondary.menu{
        background: #26292E;
        position: relative;
        width: 100%;
        height: 60px;
        z-index: 1001;
        -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.25);
        -moz-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.25);
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.25);
    }


    .ui.menu .item>.input input{
        border-radius: 30px;
        font-size: 1em;
        padding-top: .57142857em;
        padding-bottom: .57142857em;

    }

    .ui.menu .item{
        color: white;
    }

</style>
<body>
<!--IF USUARIO REPONDEU O FORMULARIO SHOW:-->
<section>
<h1 class="ui header ">Recomendado:</h1>
<br><br>

    <div class="ui four cards" style="margin-left: 8%; margin-right: 8%;">
    <?php foreach ($livros as $livro): ?>
  <div class="ui card" style="height:560px; width:305px">
      <?php

      if (isset($_GET['idusuario'])){
          $_SESSION['us_id'] = $_GET['idusuario'];
          $idusuario = $_SESSION['us_id'];
      }else{
          if (isset($_SESSION['us_id'])){
              $idusuario = $_SESSION['us_id'];
          }
      }

      ?>
      <a class="image" href="ControlerLivro.php?acao=show<?php if (isset($_SESSION)){$id = $_SESSION['us_id'];echo "&idusuario=".$id;}?>&idlivro=<?= $livro->li_idlivro ?>" style="cursor: pointer">
        <img href="ControlerLivro.php?acao=show" src="../../assets/img/livros/livro1.jpg">
      </a>
    <div class="content">
      <div class="header"><?= $livro->li_titulo ?></div>
        <?php

        if (isset($_SESSION)){
            $id = $_SESSION['us_id'];
        echo "<span class=\"right floated\">
            <a class=\"ui icon button small\" title=\"Adicionar sinópse à biblioteca\" href=\"ControlerLivro.php?acao=add_biblioteca&idusuario=$id&idlivro=$livro->li_idlivro\">";
        echo "<i class=\"add icon\"></i></a></span>";
        }
        ?>
      <div class="meta">
        <a><?= $livro->li_autor ?></a>
      <div class="description">
          <?php
          $idlivro = $livro->li_idlivro;
                    $crudGenero = new CrudGenero();
                    $generos = $crudGenero->getGeneroLivro($idlivro);
                    $iddogenero = $generos->getGlId();

                    $generodoLivro =$crudGenero->getGenero($iddogenero);
          ?>
          <a class="ui red label" style="margin-top: 6px"><?= $generodoLivro->ge_descricao ?></a>

      </div>
          <?php

          if (isset($_SESSION)){
              echo "<div class=\"extra content\">
              Classificação:
              <div class=\"ui star rating\" data-rating=\"0\" data-max-rating=\"5\"></div>
          </div>";
          }
          ?>
      </div>
    </div>

</div>
    <?php endforeach ?>
    </div>
    <br>
</section>
    <br>


<br>

<!--ELSE-->
<section>
    <div class="ui grid">
        <?php foreach ($livros as $livro): ?>
        <div class="four wide column">
            <img src="../../assets/img/imagem-exemplo.png" class="ui large rounded image">
            <span><?= $livro->li_titulo ?></span>

        </div>
        <?php endforeach ?>
    </div>
    <br>
</section>
    <br>
</body>
</html>
<script>
    $('.ui.rating')
        .rating()
    ;
</script>

