<?php

require_once "../Models/CrudLivros.php";
require_once "../Models/UsuarioCrud.php";


if (isset($_GET['acao'])){
    $action = $_GET['acao'];
}else{
    $action = 'index';
}


switch ($action){
    case 'add_livro':


        if (!isset($_POST['gravar'])) {
            $id = $_GET['idusuario'];
            @session_start();
            $_SESSION['us_id'] = $id;
            $crud = new UsuarioCrud();
            $usuario = $crud->getUsuarioId($id);
            $tipuser = $usuario->getTipUsuario();
            include "../View/Template/cabecalho.php";
            include "../View/telas/addlivro.php";
            include "../View/Template/rodape.php";
        } else {
            $livro = new Livros($_POST['li_ano'], $_POST['li_autor'], $_POST['li_censura'], $_POST['li_editora'], null, $_POST['li_paginas'], $_POST['li_titulo']);

            $crud = new CrudLivros();
            $crud->addLivro($livro);
            echo "<script>alert('O livro foi cadastrado')</script>";
            header("Location: ControlerUsuario.php");

        }

        break;

    case 'add_imagem_teste':

        $msg = false;
    if(!isset($_POST['gravarteste'])){
        include "../View/telas/addImagemTeste.php";
    }
        if(isset($_FILES['imagem'])){
            $extensao = strtolower (substr($_FILES['imagem']['name'], -4)); //pega a extensao do arquivo, transforma tudo em minusculo
            $novo_nome = md5(time()) . $extensao; //define novo nome do arquivo criptografado para não ter dois arquivos de mesmo nome
            $diretorio = "../../assets/img/livros/"; //define o diretorio pra onde vai o arquivo

            move_uploaded_file($_FILES['imagem']['tpm_name'], $diretorio.$novo_nome); //coisa o upload

            $sql = "INSERT INTO imagem (img_id, arquivo, data) VALUES (null, '$novo_nome', NOW())";

            if ($mysqlli->query($sql)){
                $msg = "Arquivo enviado com sucesso";

            }else{
                $msg = "falha ao enviar o arquivo";
            }

        }
        break;

    case 'show':
        $id = $_GET['idusuario'];
        @session_start();
        $_SESSION['us_id'] = $id;
        $crud = new UsuarioCrud();
        $usuario = $crud->getUsuarioId($id);
        $tipuser = $usuario->getTipUsuario();

//        $idlivro = $_GET['idlivro'];
//        $iduser = $_GET['iduser'];
        $tipuser = 1;
        include "../View/Template/cabecalho.php";
        include "../View/telas/livro.php";
        include "../View/Template/rodape.php";

        break;

    case 'buscar':
        $listaLivros = $crud->buscarLivros($_POST['busca']);

        break;

    case 'add_sinopse':

        if (!isset($_POST['gravar'])) {
            $id = $_GET['idusuario'];
            @session_start();
            $_SESSION['us_id'] = $id;
            $crud = new UsuarioCrud();
            $usuario = $crud->getUsuarioId($id);
            $tipuser = $usuario->getTipUsuario();

            include "../View/Template/cabecalho.php";
            include "../View/telas/addsinopse.php";
            include "../View/Template/rodape.php";
        } else {
//            $livro = new Livros($_POST['li_ano'], $_POST['li_autor'], $_POST['li_censura'], $_POST['li_editora'], null, $_POST['li_paginas'], $_POST['li_titulo']);
//
//            $crud = new CrudLivros();
//            $crud->addLivro($livro);
//            echo "<script>alert('O livro foi cadastrado')</script>";
//            header("Location: ControlerUsuario.php");

        }

        break;
}


