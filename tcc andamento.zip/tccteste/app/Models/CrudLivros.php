<?php
/**
 * Created by PhpStorm.
 * User: Hugo
 * Date: 21/07/2018
 * Time: 19:03
 */
require_once "DBConnection.php";
require_once "Livros.php";

class CrudLivros
{
    private $conexao;
    private $livros;
public function __construct()
{
    $this->conexao = DBConnection::getConexao();
}

public function addLivro(Livros $livros){
    $sql = "INSERT INTO livro (li_ano, li_autor, li_censura, li_editora,li_idlivro,li_paginas,li_titulo) VALUES ('{$livros->li_ano}' ,'{$livros->li_autor}','{$livros->li_censura}','{$livros->li_editora}',null,'{$livros->li_paginas}','{$livros->li_titulo}')";
    $this->conexao->exec($sql);
}

public function excluirLivro(int $li_idlivro){
    $sql = "DELETE FROM livro WHERE id = {$li_idlivro};";
    $this->conexao->exec($sql);
}

    public function editarLivro(array $lista){
        $sql = "UPDATE tb_produtos SET li_ano = '{$lista['li_ano']}', li_autor = {$lista['li_autor']}, li_censura= '{$lista['li_censura']}', li_editora= {$lista['li_editora']}, li_paginas= {$lista['li_paginas']}, li_titulo= {$lista['li_titulo']} WHERE li_idlivro = {$lista['li_idlivro']}";

        $this->conexao->exec($sql);
    }


    public function buscarLivros($busca){

        $meusLivros = $this->getLivros();

        $livros = [];

        $countBusca = strlen($busca);

        foreach ($meusLivros as $livro) {

            $countProduto = strlen($livro["li_titulo"]);

            $j = $countProduto;

            $verificaId = true;

            for ($i = $countBusca; $i > 1; $i--){

                $cont = str_split($livro["li_titulo"], $j)[0];

                $letra = str_split($busca, $i)[0];

                if (strtolower(str_replace(" ", "", $letra)) == strtolower(str_replace(" ", "", $cont))){
                    foreach ($livros as $produtosBuscados){
                        if ($produtosBuscados["id"] == $livro["id"]){

                            $verificaId = false;

                            break;

                        }
                    }

                    if ($verificaId){

                        $livros[] = $livro;

                        break;
                    }
                }
                if ($countBusca >= $countProduto){
                    if ($i <= $j and $j > 1){

                        $j--;
                    }
                } elseif ($countBusca < $countProduto and $i < $j){

                    $i = $countBusca;

                    $j--;
                }
            }
        }

        return $livros;
    }

    public function getLivros(){
        $consulta = $this->conexao->query("SELECT * FROM livro");

        $livros = $consulta->fetchAll(PDO::FETCH_ASSOC);
        foreach ($livros as $livro) {
            $li_ano = $livro['li_ano'];
            $li_autor = $livro['li_autor'];
            $li_censura = $livro['li_censura'];
            $li_editora = $livro['li_editora'];
            $li_paginas = $livro['li_paginas'];
            $li_titulo = $livro['li_titulo'];
            $obj = new Livros($li_ano,$li_autor,$li_censura,$li_censura,$li_editora,$li_paginas,$li_titulo);
            $ListaLivros[] = $obj;
        }
        return $ListaLivros;
    }

//    public function getGenero(){
//        $consulta = $this->conexao->query("select categoria from tb_produtos group by categoria;");
//        $lista = $consulta->fetchAll(PDO::FETCH_ASSOC);
//
//        $listaCat = [];
//        foreach ($lista as $cat){
//            $listaCat[] = $cat['categoria'];
//        }
//
//        return  $listaCat;
//    }

}