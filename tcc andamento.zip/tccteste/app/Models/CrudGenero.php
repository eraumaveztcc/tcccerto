<?php

require_once "DBConnection.php";
require_once "Generos.php";
class CrudGenero
{
    private $conexao;
    private $genero;

    public function __construct()
    {
        $this->conexao = DBConnection::getConexao();
    }

    public function addGenero(genero $genero){
        $sql = "INSERT INTO genero (ge_id, ge_descricao) VALUES ('null',{$genero->ge_descricao})";
        $this->conexao->exec($sql);
    }

    public function excluirLivro(int $li_idlivro)
    {
        $sql = "DELETE FROM livro WHERE id = {$li_idlivro};";
        $this->conexao->exec($sql);
    }

    public function getGenero(){
        $consulta = $this->conexao->query("SELECT * FROM genero");

        $generos = $consulta->fetchAll(PDO::FETCH_ASSOC);
        foreach ($generos as $genero) {
            $ge_descricao = $genero['ge_descricao'];

            $obj = new Livros($ge_descricao);
            $ListaGeneros[] = $obj;
        }
        return $ListaGeneros;
    }
}