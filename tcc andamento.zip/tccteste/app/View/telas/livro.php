<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body><br><br><br><br><br><br>
<div class="main ui container center align page">
<div class="ui segment">
    <div>
    <img src="../../../assets/img/livros700x300/livro1.png" alt="" class="ui left floated image" style="margin-right: -8em; margin-left: -8em;">
    </div>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid, assumenda autem corporis cumque debitis, facere in ipsum magnam minima minus obcaecati odit pariatur quaerat quidem, rem unde ut voluptatibus voluptatum?</p>
</div>
</div>
</body>
</html>