<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<div class="ui center aligned page grid">
    <div class="ui eight wide column left aligned form segment grid" style=" margin-top: 13%; margin-bottom: 13%">
        <form class="ui form" action="ControlerLivro.php?acao=add_livro" method="post">
        <h2 class="ui dividing header">Adicionar uma Sinopse ao $livro</h2>
        <div class="field">
            <textarea name="re_textoresenha" id="" cols="30" rows="10" required placeholder="Digite aqui sua sinopse"></textarea>
        </div>
        
        <div class="field">
        <input class="ui button" type="submit" name="gravar" value="Adicionar">
        </div>
        </form>
    </div>
</div>


</body>
</html>