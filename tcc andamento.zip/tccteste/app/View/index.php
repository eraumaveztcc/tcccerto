<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.9/semantic.min.css"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.9/semantic.min.js"></script>

<style>

    body{
        background-color: #2F3238;
    }
    .ui.secondary.menu{
        background: #26292E;
        position: relative;
        width: 100%;
        height: 60px;
        z-index: 1001;
        -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.25);
        -moz-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.25);
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.25);
    }


    .ui.menu .item>.input input{
        border-radius: 30px;
        font-size: 1em;
        padding-top: .57142857em;
        padding-bottom: .57142857em;

    }

    .ui.menu .item{
        color: white;
    }

</style>
<body>
<!--IF USUARIO REPONDEU O FORMULARIO SHOW:-->
<section>
<h1 class="ui header ">Recomendado:</h1>
<br><br>

    <div class="ui four cards" style="margin-left: 5%; margin-right: 5%;">
    <?php foreach ($livros as $livro): ?>   
  <div class="ui card" style="height:500px; width:300px">
      <div class="image" onclick="location.href='ControlerLivro.php?acao=show'" style="cursor: pointer">
        <img href="ControlerLivro.php?acao=show" src="../../assets/img/livros/livro1.jpg">
      </div>
    <div class="content">
      <div class="header"><?= $livro->li_titulo ?></div>
      <div class="meta">
        <a><?= $livro->li_autor ?></a>
      </div>
      <div class="extra content">
        Classificação:
      <div class="ui star rating" data-rating="4"></div>
      </div>
    </div>

</div>
    <?php endforeach ?>

    <br>
</section>
    <br>


<br>

<!--ELSE-->
<section>
    <div class="ui grid">
        <?php foreach ($livros as $livro): ?>
        <div class="four wide column">
            <img src="../../assets/img/imagem-exemplo.png" class="ui large rounded image">
            <span><?= $livro->li_titulo ?></span>

        </div>
        <?php endforeach ?>
    </div>
    <br>
</section>
    <br>
</body>
</html>