<div class="ui inverted vertical footer segment">
    <div class="ui center aligned container" style="padding: 5em;">
        <p>INSTITUTO FEDERAL CATARINENSE - CAMPUS ARAQUARI - Alunos: Hugo Gutzmann Puga, Tainá C. Vollmann e Cecilia de Borba</p>
    </div>
</div>